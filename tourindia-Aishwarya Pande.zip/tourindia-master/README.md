<div align="center">
	<a href="https://mrjatinchauhan.github.io/tourindia/"><img src="./pictures/tour-india.jpg"></a>
	<h4>A simple Tourism Website Portfolio which shows travel destinations across various part of Country. This theme is made using Bootstrap features several content sections, a responsive portfolio grid (tourist-places), window modals for each portfolio item, Blogs section and AboutUs Section</h4>
</div>

## [Live Preview](https://mrjatinchauhan.github.io/tourindia/)
[![Tour India Preview](./pictures/welcoming-page.png)](https://mrjatinchauhan.github.io/tourindia/)
[![Glimpse Preview](./pictures/parts-glimpse.png)](https://mrjatinchauhan.github.io/tourindia/)

## Wireframe
![Tour India Wireframe](./pictures/wireframe-pc.png)

## Usage
After downloading, simply edit the HTML and CSS files included with the template in a code editor to make changes. These are the only files you need to worry about, you can ignore everything else! To preview the changes you make to the code, you can open the `index.html` file in your web browser.
